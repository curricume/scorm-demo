function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6Lbe8JDaW3h":
        Script1();
        break;
      case "61XsviieI2N":
        Script2();
        break;
      case "6mwLLJH7lvh":
        Script3();
        break;
      case "6BekuL83Dkm":
        Script4();
        break;
      case "5yqwyz9BpkD":
        Script5();
        break;
      case "66I6OIHuAhw":
        Script6();
        break;
      case "5prkV6Zk0HZ":
        Script7();
        break;
      case "65pL6uZDhEp":
        Script8();
        break;
      case "6MzW6QKAwfU":
        Script9();
        break;
      case "6KoIMXteDaR":
        Script10();
        break;
  }
}

function Script1()
{
  objLMS.SetScore(10,100,0)
objLMS.CommitData();
}

function Script2()
{
  objLMS.SetScore(20,100,0)
objLMS.CommitData();
}

function Script3()
{
  objLMS.SetScore(30,100,0)
objLMS.CommitData();
}

function Script4()
{
  objLMS.SetScore(40,100,0)
objLMS.CommitData();
}

function Script5()
{
  objLMS.SetScore(50,100,0)
objLMS.CommitData();
}

function Script6()
{
  objLMS.SetScore(60,100,0)
objLMS.CommitData();
}

function Script7()
{
  objLMS.SetScore(70,100,0)
objLMS.CommitData();
}

function Script8()
{
  objLMS.SetScore(80,100,0)
objLMS.CommitData();
}

function Script9()
{
  objLMS.SetScore(90,100,0)
objLMS.CommitData();
}

function Script10()
{
  objLMS.SetScore(100,100,0)
SCORM_CallLMSSetValue("cmi.core.lesson_status", "completed");
objLMS.CommitData();
}

